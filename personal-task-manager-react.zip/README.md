# Personal Task Manager — ICT104 ReactJS

A complete ReactJS implementation for the ICT104 Front-End Frameworks individual assignment.

## Included requirements

- Application home page with title, student details placeholders and description
- Functional React components: Header, TaskForm, TaskList, TaskItem, API section and Footer
- Props passed between components
- `useState` for tasks, forms, filters and UI state
- `useEffect` for local storage persistence, document title updates and API loading
- Form validation with friendly error messages
- Add, complete/uncomplete and delete tasks
- Search and task filtering
- Local storage persistence
- Dark mode
- Responsive mobile-friendly design
- Fetch API integration with JSONPlaceholder
- Five external API records displayed
- No React class components

## Run locally

Install Node.js (LTS recommended), then:

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.

For a production build:

```bash
npm run build
npm run preview
```

## Before submission

1. Open `src/App.jsx`.
2. Replace `[YOUR NAME]` and `[YOUR REGISTRATION NUMBER]`.
3. Test adding, completing, searching, filtering and deleting tasks.
4. Confirm the API records load.
5. Push the project to GitHub.
6. Deploy to Vercel, Netlify or GitHub Pages.
7. Add screenshots and the repository/deployment URLs to the required PDF report.
8. Complete the AI Usage Declaration honestly.

## Suggested GitHub structure

```
personal-task-manager/
├── src/
│   ├── App.jsx
│   ├── main.jsx
│   └── styles.css
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## API

The app reads five records from:

https://jsonplaceholder.typicode.com/todos?_limit=5

## Academic note

Use this project as a learning/development starting point and make sure you understand the implementation before submitting. The assignment states that students must be able to explain and justify their submitted solution.
