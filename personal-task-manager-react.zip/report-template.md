# ICT104 — Individual Assignment Report

## Section 1 — Student Information

**Student Name:** [YOUR NAME]  
**Registration Number:** [YOUR REGISTRATION NUMBER]

## Section 2 — Application Overview

### Purpose
Personal Task Manager Web Application developed using ReactJS.

### Main Features
- Create tasks with a title and priority
- Mark tasks as completed
- Delete tasks
- Search and filter tasks
- Persist tasks with local storage
- Dark mode
- Display external API data

## Section 3 — React Concepts Used

### Components
Explain Header, TaskForm, TaskList, TaskItem, ApiData and Footer.

### Props
Explain how callbacks and task data are passed between parent and child components.

### State Management
Explain `useState` for task data, form fields, filters and UI state.

### Hooks
Explain `useEffect` for API loading, local storage and page title updates.

### Forms
Explain controlled inputs and validation.

### API Integration
Explain Fetch API and JSONPlaceholder.

## Section 4 — Screenshots

Add screenshots of:
1. Home page
2. Task creation form
3. Task list
4. API data display
5. Additional features such as search, filtering, dark mode or mobile layout

## Section 5 — GitHub Repository

[PASTE PUBLIC GITHUB REPOSITORY URL]

## Section 6 — Deployment URL

[PASTE PUBLIC DEPLOYMENT URL]

## Section 7 — AI Usage Declaration

"I used the following AI tools during the development of this assignment: [COMPLETE HONESTLY]. The AI tools were used for the following purposes: [COMPLETE HONESTLY]. I confirm that I understand the submitted solution and can explain all parts of the implementation."
