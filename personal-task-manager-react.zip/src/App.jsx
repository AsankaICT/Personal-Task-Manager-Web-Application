import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, Circle, ClipboardList, Moon, Plus, Search, Sun, Trash2, X } from "lucide-react";

const INITIAL_TASKS = [
  { id: crypto.randomUUID(), title: "Review React fundamentals", priority: "High", completed: false },
  { id: crypto.randomUUID(), title: "Complete assignment documentation", priority: "Medium", completed: false },
  { id: crypto.randomUUID(), title: "Prepare deployment checklist", priority: "Low", completed: true },
];

function Header({ darkMode, onToggleDark }) {
  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-icon"><ClipboardList size={23} /></div>
        <div>
          <strong>TaskFlow</strong>
          <span>Personal Task Manager</span>
        </div>
      </div>
      <button className="icon-button" onClick={onToggleDark} aria-label="Toggle dark mode">
        {darkMode ? <Sun size={19} /> : <Moon size={19} />}
      </button>
    </header>
  );
}

function TaskForm({ onAdd }) {
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [error, setError] = useState("");

  function submit(e) {
    e.preventDefault();
    const clean = title.trim();
    if (!clean) {
      setError("Please enter a task title.");
      return;
    }
    if (clean.length < 3) {
      setError("Task title must contain at least 3 characters.");
      return;
    }
    onAdd({ title: clean, priority });
    setTitle("");
    setPriority("Medium");
    setError("");
  }

  return (
    <form className="card form-card" onSubmit={submit}>
      <div className="section-heading">
        <div>
          <p className="eyebrow">Create a task</p>
          <h2>Add something to your list</h2>
        </div>
        <div className="round-icon"><Plus size={19} /></div>
      </div>

      <label>
        Task title
        <input
          value={title}
          onChange={(e) => { setTitle(e.target.value); if (error) setError(""); }}
          placeholder="e.g. Finish React assignment"
          maxLength={100}
        />
      </label>

      <div className="form-row">
        <label>
          Priority
          <select value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option>Low</option>
            <option>Medium</option>
            <option>High</option>
          </select>
        </label>
        <button className="primary-button" type="submit">
          <Plus size={18} /> Add Task
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}
    </form>
  );
}

function TaskItem({ task, onToggle, onDelete }) {
  return (
    <div className={`task-item ${task.completed ? "completed" : ""}`}>
      <button className="check-button" onClick={() => onToggle(task.id)} aria-label="Toggle task completion">
        {task.completed ? <CheckCircle2 size={22} /> : <Circle size={22} />}
      </button>
      <div className="task-content">
        <span className="task-title">{task.title}</span>
        <span className={`priority ${task.priority.toLowerCase()}`}>{task.priority} priority</span>
      </div>
      <button className="delete-button" onClick={() => onDelete(task.id)} aria-label="Delete task">
        <Trash2 size={18} />
      </button>
    </div>
  );
}

function TaskList({ tasks, filter, setFilter, search, setSearch, onToggle, onDelete, onClearCompleted }) {
  const filtered = tasks.filter((task) => {
    const matchesFilter =
      filter === "All" ||
      (filter === "Active" && !task.completed) ||
      (filter === "Completed" && task.completed);
    const matchesSearch = task.title.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <section className="card task-card">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Your tasks</p>
          <h2>{tasks.length} {tasks.length === 1 ? "task" : "tasks"}</h2>
        </div>
        <button className="text-button" onClick={onClearCompleted}>Clear completed</button>
      </div>

      <div className="toolbar">
        <div className="search-box">
          <Search size={17} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tasks..." />
          {search && <button onClick={() => setSearch("")}><X size={15} /></button>}
        </div>
        <div className="filters">
          {["All", "Active", "Completed"].map((item) => (
            <button key={item} className={filter === item ? "active" : ""} onClick={() => setFilter(item)}>
              {item}
            </button>
          ))}
        </div>
      </div>

      <div className="task-list">
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"><ClipboardList size={27} /></div>
            <strong>No matching tasks</strong>
            <span>Add a new task or change your filter.</span>
          </div>
        ) : (
          filtered.map((task) => (
            <TaskItem key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} />
          ))
        )}
      </div>
    </section>
  );
}

function ApiData() {
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    fetch("https://jsonplaceholder.typicode.com/todos?_limit=5")
      .then((res) => {
        if (!res.ok) throw new Error("Unable to load API data.");
        return res.json();
      })
      .then((data) => {
        if (!cancelled) setTodos(data);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, []);

  return (
    <section className="card api-card">
      <div className="section-heading">
        <div>
          <p className="eyebrow">External API</p>
          <h2>Sample todo records</h2>
        </div>
        <span className="api-badge">JSONPlaceholder</span>
      </div>
      {loading && <div className="loading">Loading records...</div>}
      {error && <div className="error-message">{error}</div>}
      {!loading && !error && (
        <div className="api-list">
          {todos.map((todo) => (
            <div className="api-row" key={todo.id}>
              <span className="api-number">{String(todo.id).padStart(2, "0")}</span>
              <span>{todo.title}</span>
              <span className={`api-status ${todo.completed ? "done" : ""}`}>
                {todo.completed ? "Done" : "Open"}
              </span>
            </div>
          ))}
        </div>
      )}
      <p className="api-note">Data is retrieved with the browser Fetch API and displayed inside the application.</p>
    </section>
  );
}

function Footer() {
  return (
    <footer>
      <span>TaskFlow · ReactJS Front-End Frameworks</span>
      <span>Built with functional components, props, hooks &amp; Fetch API</span>
    </footer>
  );
}

export default function App() {
  const [tasks, setTasks] = useState(() => {
    try {
      const saved = localStorage.getItem("taskflow-tasks");
      return saved ? JSON.parse(saved) : INITIAL_TASKS;
    } catch {
      return INITIAL_TASKS;
    }
  });
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem("taskflow-dark") === "true");
  const [filter, setFilter] = useState("All");
  const [search, setSearch] = useState("");

  useEffect(() => {
    localStorage.setItem("taskflow-tasks", JSON.stringify(tasks));
    document.title = `${tasks.filter(t => !t.completed).length} active tasks · TaskFlow`;
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem("taskflow-dark", String(darkMode));
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  function addTask(data) {
    setTasks((current) => [{ id: crypto.randomUUID(), ...data, completed: false }, ...current]);
  }

  function toggleTask(id) {
    setTasks((current) => current.map((task) => task.id === id ? { ...task, completed: !task.completed } : task));
  }

  function deleteTask(id) {
    setTasks((current) => current.filter((task) => task.id !== id));
  }

  function clearCompleted() {
    setTasks((current) => current.filter((task) => !task.completed));
  }

  const stats = useMemo(() => ({
    total: tasks.length,
    completed: tasks.filter((t) => t.completed).length,
    active: tasks.filter((t) => !t.completed).length
  }), [tasks]);

  return (
    <div className="app-shell">
      <Header darkMode={darkMode} onToggleDark={() => setDarkMode(v => !v)} />
      <main>
        <section className="hero">
          <div>
            <p className="eyebrow">ICT104 · ReactJS</p>
            <h1>Stay focused.<br /><span>Get things done.</span></h1>
            <p className="hero-copy">A clean personal task manager for creating, tracking, and completing everyday tasks.</p>
          </div>
          <div className="student-card">
            <span>Student</span>
            <strong>[YOUR NAME]</strong>
            <small>Registration No: [YOUR REGISTRATION NUMBER]</small>
          </div>
        </section>

        <section className="stats">
          <div><span>Total tasks</span><strong>{stats.total}</strong></div>
          <div><span>Active</span><strong>{stats.active}</strong></div>
          <div><span>Completed</span><strong>{stats.completed}</strong></div>
        </section>

        <div className="grid">
          <div>
            <TaskForm onAdd={addTask} />
            <ApiData />
          </div>
          <TaskList
            tasks={tasks}
            filter={filter}
            setFilter={setFilter}
            search={search}
            setSearch={setSearch}
            onToggle={toggleTask}
            onDelete={deleteTask}
            onClearCompleted={clearCompleted}
          />
        </div>
      </main>
      <Footer />
    </div>
  );
}